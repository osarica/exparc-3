(function(){
var R2C_LABEL={'Planning applications':'Change of use & planning','Renovation drawings':'Fit-out drawings','Garden rooms & outdoor':'Outdoor structures & licences','Design & space planning':'Space planning & design','Loft, garage & basement drawings':'Conversion drawings'};
var R2C={"extension-drawings": "extension-drawings", "building-regulations-drawings": "building-regulations-drawings", "conversion-drawings": "conversion-drawings", "planning-applications": "change-of-use-planning", "renovation-drawings": "fit-out-drawings", "measured-surveys": "measured-surveys", "garden-room-drawings": "outdoor-structures", "interior-design-space-planning": "space-planning-design"};
function toCommercial(h){ var m=h.match(/^\/residential\/([a-z0-9-]+)\/(.*)$/); if(!m) return h.replace('/residential/','/commercial/'); return '/commercial/'+(R2C[m[1]]||m[1])+'/'+m[2]; }

  function getAud(){try{return localStorage.getItem('exp_aud')==='biz'?'biz':'home';}catch(e){return 'home';}}
  function setAud(v){try{localStorage.setItem('exp_aud',v);}catch(e){}}
  document.addEventListener('DOMContentLoaded',function(){
    var a=getAud();
    document.documentElement.classList.toggle('biz', a==='biz');
    document.querySelectorAll('.tabs a, .aud a').forEach(function(el){
      var isBiz=(el.getAttribute('href')||'').indexOf('/commercial')>-1;
      el.classList.toggle('on',(a==='biz')===isBiz);
      el.addEventListener('click',function(){ setAud(isBiz?'biz':'home'); });
    });
    if(a==='biz'){
      document.querySelectorAll('a[href^="/residential/"]').forEach(function(el){
        if(el.hasAttribute('data-keep-aud')) return;      // "see the homeowner version" links
        if(el.closest('.foot')) return;                    // footer lists both audiences on purpose
        el.setAttribute('href', toCommercial(el.getAttribute('href')));
        var lb=el.querySelector('b')||el; var tx=(lb.textContent||'').trim(); if(R2C_LABEL[tx]) lb.textContent=R2C_LABEL[tx];
      });
      var svc=document.querySelector('.nav .has-drop > a[href="/architectural-drawing-services/"]');
      if(svc) svc.setAttribute('href','/commercial/#services');
      document.querySelectorAll('a[href="/architectural-drawing-services/"]').forEach(function(el){
        if(el.closest('.foot')||el.hasAttribute('data-keep-aud')) return;
        el.setAttribute('href','/commercial/#services');
      });
      var swaps=[['link[rel="icon"][type="image/svg+xml"]','/favicon-biz.svg'],['link[rel="icon"][sizes="32x32"]','/favicon-biz-32.png'],
        ['link[rel="icon"][sizes="16x16"]','/favicon-biz-16.png'],['link[rel="icon"][href="/favicon.ico"]','/favicon-biz.ico'],
        ['link[rel="apple-touch-icon"]','/apple-touch-icon-biz.png']];
      swaps.forEach(function(s){var el=document.querySelector(s[0]); if(el) el.href=s[1];});
    }
    // filters + pagination
    var grids=[].slice.call(document.querySelectorAll('.pgrid.paged'));
    grids.forEach(function(grid){
      var per=parseInt(grid.getAttribute('data-per')||'6',10);
      var pager=grid.parentNode.querySelector('.pager');
      var items=[].slice.call(grid.querySelectorAll('.gitem'));
      var filter='all', page=1;
      function matched(){ return items.filter(function(it){ return filter==='all'||it.getAttribute('data-cat')===filter; }); }
      function render(){
        var vis=matched(); var pages=Math.max(1,Math.ceil(vis.length/per));
        if(page>pages) page=pages;
        items.forEach(function(it){ it.style.display='none'; });
        vis.slice((page-1)*per, page*per).forEach(function(it){ it.style.display=''; });
        if(!pager) return;
        pager.innerHTML='';
        if(pages<2) return;
        function mk(label,target,dis,on){
          var b=document.createElement('button'); b.textContent=label;
          if(dis) b.disabled=true; if(on) b.className='on';
          b.addEventListener('click',function(){ page=target; render(); grid.scrollIntoView({behavior:'smooth',block:'start'}); });
          pager.appendChild(b);
        }
        mk('\u2039', page-1, page===1, false);
        for(var i=1;i<=pages;i++) mk(String(i), i, false, i===page);
        mk('\u203a', page+1, page===pages, false);
      }
      grid.__render=render; grid.__setFilter=function(f){ filter=f; page=1; render(); };
      render();
    });
    var filterBtns=document.querySelectorAll('[data-filter]');
    filterBtns.forEach(function(btn){
      btn.addEventListener('click',function(){
        var f=btn.getAttribute('data-filter');
        var scope=btn.closest('.in')||document;
        scope.querySelectorAll('[data-filter]').forEach(function(b){ b.classList.toggle('on', b===btn); });
        var grid=scope.querySelector('.pgrid.paged');
        if(grid&&grid.__setFilter){ grid.__setFilter(f); return; }
        document.querySelectorAll('.gitem').forEach(function(it){
          it.style.display=(f==='all'||it.getAttribute('data-cat')===f)?'':'none';
        });
      });
    });
    // deep-link a filter from the Projects mega menu: /projects/?filter=loft
    try{
      var want=new URLSearchParams(location.search).get('filter');
      if(want){
        var b=document.querySelector('[data-filter="'+want+'"]');
        if(b){ b.click(); var g=document.querySelector('.pgrid.paged'); if(g) g.scrollIntoView({behavior:'smooth',block:'start'}); }
      }
    }catch(e){}
    // carry hero route-check answers into the quote form
    try{
      var q=new URLSearchParams(location.search);
      ['postcode','project','property','door_number'].forEach(function(k){
        var v=q.get(k); if(!v) return;
        var el=document.querySelector('[name="'+k+'"]');
        if(!el) return;
        if(el.tagName==='SELECT'){
          var hit=[].slice.call(el.options).filter(function(o){return o.value===v||o.text===v;})[0];
          if(hit){ el.value=hit.value; } else { var o=new Option(v,v,true,true); el.add(o,0); el.value=v; }
        } else { el.value=v; }
        el.classList.add('prefilled');
      });
    }catch(e){}
    document.querySelectorAll('[data-carousel]').forEach(function(c){
      if(c.querySelector('.hs-track')) return;
      var track=c.querySelector('.ctrack');
      var prev=c.querySelector('.cprev'), next=c.querySelector('.cnext');
      if(next&&track) next.addEventListener('click',function(){ track.scrollBy({left:Math.round(track.clientWidth*0.8),behavior:'smooth'}); });
      if(prev&&track) prev.addEventListener('click',function(){ track.scrollBy({left:-Math.round(track.clientWidth*0.8),behavior:'smooth'}); });
    });
    var imgs=[].slice.call(document.querySelectorAll('.gimg'));
    if(imgs.length){
      var lb=document.createElement('div'); lb.className='lightbox';
      lb.innerHTML='<button class="lb-close" aria-label="Close">&times;</button><button class="lb-prev" aria-label="Previous">&#8249;</button><figure><img alt=""><figcaption></figcaption></figure><button class="lb-next" aria-label="Next">&#8250;</button>';
      document.body.appendChild(lb);
      var lbimg=lb.querySelector('img'), cap=lb.querySelector('figcaption'), cur=0;
      function show(i){ cur=(i+imgs.length)%imgs.length; var im=imgs[cur]; lbimg.src=im.getAttribute('data-full')||im.src; cap.textContent=im.getAttribute('data-cap')||''; lb.classList.add('open'); }
      imgs.forEach(function(im,i){ im.addEventListener('click',function(){ show(i); }); });
      lb.querySelector('.lb-close').addEventListener('click',function(){ lb.classList.remove('open'); });
      lb.querySelector('.lb-next').addEventListener('click',function(e){ e.stopPropagation(); show(cur+1); });
      lb.querySelector('.lb-prev').addEventListener('click',function(e){ e.stopPropagation(); show(cur-1); });
      lb.addEventListener('click',function(e){ if(e.target===lb||e.target.tagName==='FIGURE') lb.classList.remove('open'); });
      document.addEventListener('keydown',function(e){ if(!lb.classList.contains('open'))return; if(e.key==='Escape')lb.classList.remove('open'); if(e.key==='ArrowRight')show(cur+1); if(e.key==='ArrowLeft')show(cur-1); });
      var sx=0; lb.addEventListener('touchstart',function(e){ sx=e.touches[0].clientX; },{passive:true});
      lb.addEventListener('touchend',function(e){ var dx=e.changedTouches[0].clientX-sx; if(Math.abs(dx)>40) show(cur+(dx<0?1:-1)); },{passive:true});
    }
    document.querySelectorAll('img.gimg, .pcard img').forEach(function(im){
      im.addEventListener('error',function(){ if(!im.getAttribute('data-fb')){ im.setAttribute('data-fb','1'); im.src='/placeholder.jpg'; } });
    });
  });
})();


/* Native menu behaviour: hover with intent on desktop, tap on touch, Escape + outside click,
   one full-viewport scrim, aria state kept in sync. */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded',fn); }
  ready(function(){
    var drops=[].slice.call(document.querySelectorAll('.has-drop'));
    if(!drops.length) return;
    var scrim=document.createElement('div'); scrim.className='nav-scrim'; document.body.appendChild(scrim);
    var canHover=window.matchMedia('(hover:hover) and (pointer:fine)').matches;
    var open=null, t=null;
    function setOpen(el){
      if(t){ clearTimeout(t); t=null; }
      if(open&&open!==el) shut(open);
      if(!el) return;
      el.classList.add('open');
      var a=el.querySelector('a'); if(a) a.setAttribute('aria-expanded','true');
      open=el; document.body.classList.add('nav-open');
    }
    function shut(el){
      el.classList.remove('open');
      var a=el.querySelector('a'); if(a) a.setAttribute('aria-expanded','false');
      if(open===el) open=null;
      if(!open) document.body.classList.remove('nav-open');
    }
    function shutAll(){ drops.forEach(shut); document.body.classList.remove('nav-open'); }
    function delayedShut(){ if(t) clearTimeout(t); t=setTimeout(shutAll,160); }
    drops.forEach(function(el){
      var a=el.querySelector('a');
      if(a){ a.setAttribute('aria-haspopup','true'); a.setAttribute('aria-expanded','false'); }
      if(canHover){
        el.addEventListener('mouseenter',function(){ setOpen(el); });
        el.addEventListener('mouseleave',delayedShut);
      }
      el.addEventListener('focusin',function(){ setOpen(el); });
      if(a){
        a.addEventListener('click',function(e){
          if(!canHover && !el.classList.contains('open')){ e.preventDefault(); setOpen(el); }
        });
      }
    });
    scrim.addEventListener('click',shutAll);
    document.addEventListener('keydown',function(e){ if(e.key==='Escape') shutAll(); });
    document.addEventListener('click',function(e){
      if(open && !open.contains(e.target)) shutAll();
    });
    var last=0;
    window.addEventListener('scroll',function(){
      var y=window.pageYOffset||document.documentElement.scrollTop;
      if((y>8)!==(last>8)) document.body.classList.toggle('scrolled', y>8);
      last=y;
    },{passive:true});
  });
})();

/* Keep every dropdown inside the viewport: align to its trigger, then clamp. */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded',fn); }
  ready(function(){
    var GAP=16;
    function placePanel(el){
      var panel=el.querySelector('.drop'); if(!panel) return;
      if(window.innerWidth<=640 || el.classList.contains('wide')){ panel.style.left=''; return; }
      panel.style.left='0px';
      var trig=el.getBoundingClientRect();
      var w=panel.offsetWidth;
      var maxLeft=window.innerWidth-GAP-w;
      var left=Math.max(GAP, Math.min(trig.left, maxLeft));
      panel.style.left=Math.round(left-trig.left)+'px';
    }
    function placeAll(){
      document.querySelectorAll('.has-drop').forEach(function(el){
        if(el.classList.contains('open')) placePanel(el);
        else { var p=el.querySelector('.drop'); if(p) p.style.left=''; }
      });
    }
    var mo=new MutationObserver(function(muts){
      muts.forEach(function(m){
        if(m.attributeName==='class' && m.target.classList.contains('open')) placePanel(m.target);
      });
    });
    document.querySelectorAll('.has-drop').forEach(function(el){
      mo.observe(el,{attributes:true,attributeFilter:['class']});
      el.addEventListener('mouseenter',function(){ placePanel(el); });
      el.addEventListener('focusin',function(){ placePanel(el); });
    });
    var t; window.addEventListener('resize',function(){ clearTimeout(t); t=setTimeout(placeAll,120); },{passive:true});
  });
})();

/* Hero projects deck: one sheet at a time, switched with a soft paper motion.
   Arrows, dots, swipe and keyboard. Hidden sheets stay out of the tab order. */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded',fn); }
  ready(function(){
    document.querySelectorAll('.hero-slider').forEach(function(sl){
      var track=sl.querySelector('.hs-track'); if(!track) return;
      var slides=[].slice.call(track.querySelectorAll('.hs-slide'));
      if(slides.length<2) return;
      sl.classList.add('hs-deck');
      var bar=sl.querySelector('.hs-bar');
      var dots=document.createElement('div'); dots.className='hs-dots';
      slides.forEach(function(s,n){
        var b=document.createElement('button');
        b.type='button'; b.setAttribute('aria-label','Show project '+(n+1)+' of '+slides.length);
        b.addEventListener('click',function(e){ e.preventDefault(); go(n); });
        dots.appendChild(b);
      });
      if(bar) bar.insertBefore(dots, bar.lastElementChild); else sl.appendChild(dots);
      var i=0, timer=null;
      function paint(){
        slides.forEach(function(s,n){
          var on=(n===i);
          s.classList.toggle('is-active',on);
          s.setAttribute('aria-hidden', on?'false':'true');
          s.setAttribute('tabindex', on?'0':'-1');
        });
        [].slice.call(dots.children).forEach(function(d,n){ d.classList.toggle('on',n===i); });
      }
      function go(n,dir){
        var len=slides.length;
        n=(n+len)%len;
        if(n===i || sl.dataset.busy==='1') return;
        if(dir===undefined){ dir=((n-i+len)%len)<=len/2 ? 1 : -1; }
        var prev=i; i=n;
        sl.classList.remove('dir-next','dir-prev');
        void sl.offsetWidth;                       // restart the animation cleanly
        sl.classList.add(dir>0?'dir-next':'dir-prev');
        var leaving=slides[prev];
        leaving.classList.remove('is-active');
        leaving.classList.add('is-leaving');        // stays opaque underneath
        sl.dataset.busy='1';
        if(timer) clearTimeout(timer);
        timer=setTimeout(function(){
          leaving.classList.remove('is-leaving');
          sl.dataset.busy='0';
        },390);
        paint();
      }
      var prevBtn=sl.querySelector('.cprev'), nextBtn=sl.querySelector('.cnext');
      if(prevBtn) prevBtn.addEventListener('click',function(e){ e.preventDefault(); go(i-1,-1); });
      if(nextBtn) nextBtn.addEventListener('click',function(e){ e.preventDefault(); go(i+1,1); });
      var sx=0, sy=0, moved=false;
      track.addEventListener('touchstart',function(e){ sx=e.touches[0].clientX; sy=e.touches[0].clientY; moved=false; },{passive:true});
      track.addEventListener('touchmove',function(e){
        if(Math.abs(e.touches[0].clientX-sx)>10) moved=true;
      },{passive:true});
      track.addEventListener('touchend',function(e){
        var dx=e.changedTouches[0].clientX-sx, dy=e.changedTouches[0].clientY-sy;
        if(moved && Math.abs(dx)>45 && Math.abs(dx)>Math.abs(dy)){
          if(e.cancelable) e.preventDefault();
          go(i + (dx<0?1:-1), dx<0?1:-1);
        }
      });
      sl.addEventListener('keydown',function(e){
        if(e.key==='ArrowRight'){ e.preventDefault(); go(i+1,1); }
        if(e.key==='ArrowLeft'){ e.preventDefault(); go(i-1,-1); }
      });
      paint();
    });
  });
})();

/* Mobile menu: JS owns the open state so the browser cannot restore it on navigation,
   which is what left the menu stuck open when you tapped through to a page. */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded',fn); }
  ready(function(){
    var toggle=document.getElementById('mnav');
    var burger=document.querySelector('.burger');
    var nav=document.querySelector('.nav');
    if(!toggle||!nav) return;
    nav.id=nav.id||'mnav-panel';
    if(burger){ burger.setAttribute('role','button'); burger.setAttribute('aria-controls','mnav-panel'); }
    function sync(){
      var on=toggle.checked;
      document.documentElement.classList.toggle('mnav-open', on);
      if(burger){ burger.setAttribute('aria-expanded', on?'true':'false');
                  burger.setAttribute('aria-label', on?'Close menu':'Open menu'); }
      if(!on){ nav.querySelectorAll('.has-drop.open').forEach(function(el){ el.classList.remove('open'); }); }
    }
    function close(){ toggle.checked=false; sync(); }
    // the browser restores checkbox state on back/forward and soft reloads: never trust it
    close();
    window.addEventListener('pageshow', close);
    toggle.addEventListener('change', sync);
    nav.addEventListener('click', function(e){
      var a=e.target.closest('a');
      if(!a) return;
      if(a.parentElement && a.parentElement.classList.contains('has-drop')) return; // accordion header
      close();
    });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape') close(); });
    window.addEventListener('resize', function(){ if(window.innerWidth>640) close(); }, {passive:true});
  });
})();


/* Mobile action bar: the phone and the quote stay one tap away once past the hero. */
(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded',fn); }
  ready(function(){
    var bar=document.querySelector('.mbar'); if(!bar) return;
    if(window.innerWidth>640) return;
    var shown=false;
    function check(){
      var y=window.pageYOffset||document.documentElement.scrollTop;
      var near=(document.body.scrollHeight-(y+window.innerHeight))<160; // out of the way at the footer
      var want=y>520 && !near;
      if(want!==shown){ shown=want; document.body.classList.toggle('mbar-on',want); bar.setAttribute('aria-hidden',want?'false':'true'); }
    }
    window.addEventListener('scroll',check,{passive:true});
    window.addEventListener('resize',function(){ if(window.innerWidth>640){ document.body.classList.remove('mbar-on'); } },{passive:true});
    check();
  });
})();

/* ================= Exp|Arc measurement layer =================
   Mirrors the Sibe setup: first-touch + last-touch attribution, every ad click ID, a page context
   event on every page, interaction events for GTM, consent mode v2, enhanced-conversion user data,
   and test-lead flagging. Vendor pixels live only in GTM, never in this file. */
(function(){
  var W=window, D=document; W.dataLayer=W.dataLayer||[];
  function dl(o){ try{ W.dataLayer.push(o); }catch(e){} }
  function ready(fn){ if(D.readyState!=='loading') fn(); else D.addEventListener('DOMContentLoaded',fn); }
  function now(){ return new Date().toISOString(); }
  var PARAMS=['utm_source','utm_medium','utm_campaign','utm_term','utm_content','utm_id',
              'gclid','gbraid','wbraid','msclkid','fbclid','li_fat_id','rdt_cid','ttclid'];
  var CLICK_IDS=['gclid','gbraid','wbraid','msclkid','fbclid','li_fat_id','rdt_cid','ttclid'];

  /* ---------- consent (UK GDPR / PECR) ---------- */
  function getConsent(){ try{ return JSON.parse(localStorage.getItem('exp_consent')||'null'); }catch(e){ return null; } }
  function consentOK(kind){ var c=getConsent(); return !!(c && c[kind]); }
  function store(){ return consentOK('analytics') ? localStorage : sessionStorage; }   // session-only until consent
  function read(k){ try{ return JSON.parse(localStorage.getItem(k)||sessionStorage.getItem(k)||'null'); }catch(e){ return null; } }
  function write(k,v){ try{ store().setItem(k, JSON.stringify(v)); }catch(e){} }

  /* ---------- channel classification ---------- */
  function channelOf(t){
    var s=(t.utm_source||'').toLowerCase(), m=(t.utm_medium||'').toLowerCase(), r=(t.referrer||'').toLowerCase();
    if(t.gclid||t.gbraid||t.wbraid) return 'paid_search_google';
    if(t.msclkid) return 'paid_search_microsoft';
    if(t.fbclid && /cpc|paid|ads/.test(m)) return 'paid_social_meta';
    if(t.li_fat_id) return 'paid_social_linkedin';
    if(t.rdt_cid) return 'paid_social_reddit';
    if(/cpc|ppc|paid|display|retarget/.test(m)) return 'paid_'+(s||'other');
    if(/email|newsletter/.test(m)) return 'email';
    if(/social/.test(m) || /facebook|instagram|linkedin|twitter|x\.com|t\.co|reddit|tiktok|pinterest/.test(r)) return 'organic_social';
    if(/google\.|bing\.|duckduckgo|yahoo\.|ecosia|yandex|baidu/.test(r)) return 'organic_search';
    if(/chatgpt|openai|perplexity|claude\.ai|gemini\.google|copilot/.test(r)) return 'ai_assistant';
    if(r && r.indexOf(location.hostname)===-1) return 'referral';
    return 'direct';
  }

  /* ---------- attribution: first touch is kept forever, last touch updates on any new campaign or external visit ---------- */
  var q=new URLSearchParams(location.search), hit={}, has=false;
  PARAMS.forEach(function(k){ var v=q.get(k); if(v){ hit[k]=v.slice(0,200); has=true; } });
  var ref=D.referrer||''; var external=ref && ref.indexOf(location.hostname)===-1;
  var touch=null;
  if(has||external){ touch=hit; touch.referrer=ref||'direct'; touch.landing_page=location.pathname+location.search; touch.ts=now(); touch.channel=channelOf(touch); }
  var ft=read('exp_ft'), lt=read('exp_lt');
  if(!ft){ ft=touch||{referrer:ref||'direct',landing_page:location.pathname+location.search,ts:now(),channel:channelOf({referrer:ref})}; write('exp_ft',ft); }
  if(touch){ lt=touch; write('exp_lt',lt); } else if(!lt){ lt=ft; write('exp_lt',lt); }
  // click IDs persist independently so a later direct visit does not lose the ad click
  var ids=read('exp_clickids')||{}; CLICK_IDS.forEach(function(k){ if(hit[k]){ ids[k]=hit[k]; ids[k+'_ts']=now(); } }); write('exp_clickids',ids);
  // first click per platform: kept forever, never overwritten (last click per platform is exp_clickids above)
  var idsFirst=read('exp_clickids_first')||{}; CLICK_IDS.forEach(function(k){ if(hit[k] && !idsFirst[k]){ idsFirst[k]=hit[k]; idsFirst[k+'_ts']=now(); } }); write('exp_clickids_first',idsFirst);
  // visit + session depth
  var sess=read('exp_sess'); var fresh=!sess||(Date.now()-(sess.last||0))>30*60*1000;
  if(fresh){ sess={id:Math.random().toString(36).slice(2,10),start:Date.now(),pages:0}; var v=(read('exp_visits')||0)+1; write('exp_visits',v); }
  sess.pages=(sess.pages||0)+1; sess.last=Date.now(); try{ sessionStorage.setItem('exp_sess',JSON.stringify(sess)); }catch(e){}
  var visits=read('exp_visits')||1;

  /* ---------- page context, every page ---------- */
  var p=location.pathname;
  var audience=/^\/commercial\//.test(p)?'commercial':(/^\/residential\//.test(p)?'residential':((localStorage.getItem('exp_aud')==='biz')?'commercial':'residential'));
  var page_type=p==='/'||p==='/commercial/'?'home':/^\/(residential|commercial)\/[^/]+\/$/.test(p)?'service':/^\/projects\/[^/]+\/$/.test(p)?'project':
    p==='/projects/'?'projects_hub':/^\/areas\/[^/]+\/$/.test(p)?'area':p==='/areas/'?'areas_hub':/^\/advice\/[^/]+\/$/.test(p)?'article':p==='/advice/'?'advice_hub':/get-a-quote/.test(p)?'quote':
    /thank-you/.test(p)?'thank_you':/contact/.test(p)?'contact':/pricing/.test(p)?'pricing':/faq/.test(p)?'faq':'other';
  var service=(p.match(/^\/(?:residential|commercial)\/([^/]+)\//)||[])[1]||'';
  var location_area=(p.match(/^\/areas\/([^/]+)\//)||[])[1]||'';
  dl({event:'page_context', page_type:page_type, audience:audience, service:service, location:location_area,
      channel_first:ft.channel, channel_last:lt.channel, visit_number:visits, session_pages:sess.pages,
      consent_analytics:consentOK('analytics')?'granted':'denied', consent_ads:consentOK('ads')?'granted':'denied'});

  /* ---------- forms: attribution as hidden fields, start + submit events ---------- */
  ready(function(){
    D.querySelectorAll('form[method="POST"]').forEach(function(f){
      function set(n,v){ if(v===undefined||v===null||v==='') return; var i=f.querySelector('input[name="'+n+'"]');
        if(!i){ i=D.createElement('input'); i.type='hidden'; i.name=n; f.appendChild(i); } i.value=String(v).slice(0,300); }
      PARAMS.forEach(function(k){ set(k, (lt&&lt[k])||(ft&&ft[k])); });
      CLICK_IDS.forEach(function(k){ set(k, ids[k]); set(k+'_ts', ids[k+'_ts']); set('ft_'+k, idsFirst[k]); set('ft_'+k+'_ts', idsFirst[k+'_ts']); });
      ['utm_source','utm_medium','utm_campaign','utm_term','utm_content'].forEach(function(k){ set('ft_'+k, ft&&ft[k]); });
      set('ft_channel', ft&&ft.channel); set('lt_channel', lt&&lt.channel);
      set('first_touch_page', ft&&ft.landing_page); set('first_referrer', ft&&ft.referrer); set('first_touch_ts', ft&&ft.ts);
      set('last_touch_page', lt&&lt.landing_page); set('last_referrer', lt&&lt.referrer);
      set('visit_number', visits); set('session_pages', sess.pages);
      set('device', /Mobi|Android/i.test(navigator.userAgent)?'mobile':(/iPad|Tablet/i.test(navigator.userAgent)?'tablet':'desktop'));
      set('submitted_page', location.pathname); set('audience', audience);
      var loadedAt=Date.now(); set('js_t', String(loadedAt));
      function readCookie(n){ var m=D.cookie.match(new RegExp('(?:^|; )'+n+'=([^;]*)')); return m?decodeURIComponent(m[1]):''; }
      var fbc=readCookie('_fbc')||(ids.fbclid?('fb.1.'+Date.now()+'.'+ids.fbclid):'');
      set('fbc', fbc); set('fbp', readCookie('_fbp'));
      var gclAw=readCookie('_gcl_aw'); set('gcl_aw', gclAw); if(!ids.gclid && gclAw){ set('gclid', gclAw.split('.').pop()); }
      var uetm=readCookie('_uetmsclkid'); set('uet_msclkid', uetm); if(!ids.msclkid && uetm){ set('msclkid', uetm.replace(/^_uet/,'')); }
      if(!ids.li_fat_id){ set('li_fat_id', readCookie('li_fat_id')); }
      var btn=f.querySelector('button[type="submit"], button:not([type])'); set('cta_text', btn?btn.textContent.trim():'');
      var fn=(f.querySelector('input[name="form-name"]')||{}).value||f.getAttribute('name')||'unknown';
      var started=false;
      f.addEventListener('focusin',function(){ if(started) return; started=true;
        dl({event:'form_start', form_name:fn, page_type:page_type, audience:audience}); });
      f.addEventListener('submit',function(){
        set('submitted_page', location.pathname); set('js_ok','1'); set('js_ms', String(Date.now()-loadedAt));
        var em=(f.querySelector('input[type="email"]')||{}).value||'', ph=(f.querySelector('input[type="tel"]')||{}).value||'';
        try{ sessionStorage.setItem('exp_ud', JSON.stringify({email:em.trim().toLowerCase(), phone:ph.replace(/[^\d+]/g,'')})); }catch(e){}
        dl({event:'lead_submit', form_name:fn, service:fn.replace(/^(res-|biz-|lm-)/,'').replace(/-end$/,''),
            audience:/^biz-/.test(fn)?'commercial':(/^res-/.test(fn)?'residential':audience), page:location.pathname});
      });
    });

    /* ---------- clicks: phone, email, downloads, CTAs, outbound, audience switch, FAQ, mobile bar ---------- */
    D.addEventListener('click',function(e){
      var a=e.target.closest('a,summary,button'); if(!a) return;
      var href=a.getAttribute('href')||'', text=(a.textContent||'').trim().replace(/\s+/g,' ').slice(0,80);
      var where=a.closest('header')?'header':a.closest('footer')?'footer':a.closest('.mbar')?'mobile_bar':a.closest('.hero')?'hero':'body';
      if(/^tel:/.test(href)) dl({event:'phone_click', phone_number:href.slice(4), link_text:text, click_location:where, page_type:page_type});
      else if(/^mailto:/.test(href)) dl({event:'email_click', link_text:text, click_location:where, page_type:page_type});
      else if(/\.(pdf|docx?)(\?|$)/i.test(href)) dl({event:'file_download', file_name:href.split('/').pop(), file_type:(href.match(/\.(\w+)(\?|$)/)||[])[1], link_text:text, page_type:page_type});
      else if(/^https?:\/\//.test(href) && href.indexOf(location.hostname)===-1) dl({event:'outbound_click', link_url:href, link_text:text});
      if(a.matches('.tabs a, .aud a')) dl({event:'audience_switch', to_audience:/commercial/i.test(text)?'commercial':'residential', click_location:where});
      if(a.tagName==='SUMMARY') dl({event:'faq_open', question:text, page_type:page_type});
      if(a.matches('.btn, .mbar a, .rel-card, .case-mini, .svc-card') && !/^(tel|mailto):/.test(href))
        dl({event:'cta_click', link_text:text, link_url:href, click_location:where, page_type:page_type, audience:audience});
    }, true);

    /* ---------- conversion page ---------- */
    if(p.indexOf('/thank-you')===0){
      var tq=new URLSearchParams(location.search), form=tq.get('form')||'unknown';
      var lead_type=form.indexOf('quote')===0?'quote':((form.indexOf('lm-')===0||form==='guide')?'guide':'enquiry');
      var ud=null; try{ ud=JSON.parse(sessionStorage.getItem('exp_ud')||'null'); sessionStorage.removeItem('exp_ud'); }catch(e){}
      var once='exp_done_'+form+'_'+(sess.id||''); var dup=false; try{ dup=!!sessionStorage.getItem(once); sessionStorage.setItem(once,'1'); }catch(e){}
      dl({event:'lead_complete', form_name:form, service:tq.get('svc')||'', lead_type:lead_type,
          is_test:tq.get('test')==='1'?'true':'false', is_duplicate:dup?'true':'false',
          value:lead_type==='quote'?100:(lead_type==='enquiry'?60:5), currency:'GBP',
          channel_first:ft.channel, channel_last:lt.channel,
          user_data: ud&&(ud.email||ud.phone) ? {email:ud.email||undefined, phone_number:ud.phone||undefined} : undefined});
    }

    /* ---------- consent banner ---------- */
    function apply(c, source){
      try{ localStorage.setItem('exp_consent', JSON.stringify(c)); }catch(e){}
      if(typeof W.gtag==='function'){
        W.gtag('consent','update',{analytics_storage:c.analytics?'granted':'denied', ad_storage:c.ads?'granted':'denied',
          ad_user_data:c.ads?'granted':'denied', ad_personalization:c.ads?'granted':'denied'});
      }
      if(c.analytics){ ['exp_ft','exp_lt','exp_clickids','exp_clickids_first','exp_visits'].forEach(function(k){ try{ var v=sessionStorage.getItem(k); if(v) localStorage.setItem(k,v); }catch(e){} }); }
      dl({event:'consent_update', consent_analytics:c.analytics?'granted':'denied', consent_ads:c.ads?'granted':'denied', consent_source:source});
    }
    W.expOpenConsent=function(){ show(true); };
    function show(force){
      if(D.querySelector('.cbar')) return;
      if(getConsent() && !force) return;
      var b=D.createElement('div'); b.className='cbar'; b.setAttribute('role','dialog'); b.setAttribute('aria-label','Cookie preferences');
      b.innerHTML='<p>We use cookies to measure how the site is used and to show relevant ads. You choose. '+
        '<a href="/cookies/">Cookie policy</a></p><div class="cbar-btns">'+
        '<button type="button" class="btn sec sm" data-c="reject">Reject non-essential</button>'+
        '<button type="button" class="btn pri sm" data-c="accept">Accept all</button></div>';
      D.body.appendChild(b); D.documentElement.classList.add('cbar-on');
      b.addEventListener('click',function(ev){ var c=ev.target.getAttribute('data-c'); if(!c) return;
        apply(c==='accept'?{analytics:true,ads:true,ts:now()}:{analytics:false,ads:false,ts:now()}, 'banner');
        b.remove(); D.documentElement.classList.remove('cbar-on'); });
    }
    var existing=getConsent();
    if(existing) dl({event:'consent_ready', consent_analytics:existing.analytics?'granted':'denied', consent_ads:existing.ads?'granted':'denied'});
    else { dl({event:'consent_ready', consent_analytics:'denied', consent_ads:'denied'}); show(false); }
    D.querySelectorAll('a[href="#cookie-settings"]').forEach(function(l){ l.addEventListener('click',function(ev){ ev.preventDefault(); show(true); }); });
  });
})();

/* Cloudflare Turnstile: invisible bot check. Switched on by the build when a site key exists (meta ts-sitekey).
   Loads on the first interaction with any form, so it costs nothing on page load. No cookies, no consent needed. */
(function(){
  var meta=document.querySelector('meta[name="ts-sitekey"]'); if(!meta) return;
  var key=meta.getAttribute('content'), loading=false, ready=false, queue=[];
  function load(cb){ if(ready){cb();return;} queue.push(cb); if(loading) return; loading=true;
    window.onTsLoad=function(){ ready=true; queue.splice(0).forEach(function(f){f();}); };
    var sc=document.createElement('script'); sc.src='https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=onTsLoad'; sc.async=true; document.head.appendChild(sc); }
  function mount(f){ if(f.querySelector('.ts-box')) return; var box=document.createElement('div'); box.className='ts-box';
    var btn=f.querySelector('button[type="submit"], button:not([type])'); f.insertBefore(box, btn||null);
    load(function(){ try{ window.turnstile.render(box,{sitekey:key, appearance:'interaction-only', action:(f.getAttribute('name')||'form').slice(0,32)}); }catch(e){} }); }
  document.addEventListener('focusin',function(e){ var f=e.target.closest&&e.target.closest('form[method="POST"]'); if(f) mount(f); },true);
  document.addEventListener('submit',function(e){ var f=e.target; if(!f.matches||!f.matches('form[method="POST"]')) return;
    mount(f); var tok=f.querySelector('input[name="cf-turnstile-response"]');
    if(tok && tok.value) return;                 // token ready, submit normally
    e.preventDefault(); var n=0; var t=setInterval(function(){ var v=f.querySelector('input[name="cf-turnstile-response"]');
      if((v&&v.value)||++n>40){ clearInterval(t); HTMLFormElement.prototype.submit.call(f); } },150); },true);
})();
