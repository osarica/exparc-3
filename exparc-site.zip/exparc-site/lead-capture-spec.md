# Exp|Arc — Lead capture & routing spec
Built to mirror the Sibe setup so Slack, GoHighLevel and Make are drop-in.

## 1. Form inventory (each posts with its own name, so routing can branch on it)
| Form name | Where | Intent |
|---|---|---|
| `quote` | /get-a-quote/ | Main quote request (hero route-check funnels here) |
| `pricing` | /pricing/ | Price-led enquiry |
| `res-<service>` x8 | /residential/<service>/ (top + bottom) | Service-specific, residential |
| `biz-<service>` x8 | /business/<service>/ | Service-specific, commercial |
| `lm-<service>` x8 | service pages | Lead magnet, guide download by email |
| `guide` | /free-guides/ | Homeowner's guide download |
| `contact` | /contact/ | General enquiry |

Hero route-check is a GET step: it carries `postcode` + `project` into /get-a-quote/ and prefills them. Capture happens on the quote form, so there is one clean conversion point.

## 2. Fields captured on every submission (matches the Sibe Slack message format)
Lead: `name`, `phone`, `email`, `postcode` (optional), `door_number` (optional), `project`, `property`, `message`
`door_number` is asked so the team can check the council planning portal for existing drawings and planning history before the first call. Treat it as a qualification accelerator in the CRM, not a required field.
Attribution: `utm_source`, `utm_medium`, `utm_campaign`, `utm_term` (keyword), `utm_content` (ad), `gclid` (Google), `msclkid` (Bing), `fbclid` (Meta), `li_fat_id` (LinkedIn)
Context: `first_touch_page`, `first_referrer`, `submitted_page`, `cta_text`, `form-name`
First touch and click IDs persist in localStorage, so a lead that lands on a blog and converts a week later still reports the original ad.

## 3. Conversion point
All forms redirect to `/thank-you/` (noindex). Fire Google Ads / GA4 / Bing / LinkedIn / Meta conversions there. One page, every channel.

## 4. Slack routing (when the free workspace is up) — proposed channels
- `#exparc-quote-requests` — `quote`, `pricing`, `contact` (sales-ready)
- `#exparc-service-enquiries` — `res-*` and `biz-*` (branch residential vs commercial on the prefix)
- `#exparc-guide-downloads` — `lm-*`, `guide` (nurture, not sales-ready)
- `#exparc-test-submissions` — test traffic, see below
Message format, as proven at Sibe: Email / Phone / Postcode / Project / Notes / Source-Medium / Campaign / Keyword / Ad content / First-touch page / CTA / Referrer.

## 5. Test-lead filter (apply from day one, Sibe learning)
Route to the test channel only, skip CRM and email, if ANY:
- name is exactly `test` (exact, not contains, to avoid false positives)
- email domain is `@exparc.co.uk` or the agency domain
- email is one of the team's own addresses
Add the negation of every test signal to the real routes so tests never reach GoHighLevel.

## 6. GoHighLevel
One inbound webhook can take every form: branch on `form-name` inside the workflow rather than building one webhook per form. Map the attribution fields to custom fields so ad spend is reportable per lead.

## 7. Retargeting readiness
Each audience has clean URL prefixes for audience building: `/residential/*`, `/business/*`, `/projects/*`, `/guides/*`, `/thank-you/` (exclude converters). Pixels can be added sitewide in one place once accounts exist.


## Cloudflare Pages wiring (current)
- All POST forms submit to `/api/lead` (functions/api/lead.js). Honeypot `bot-field` is dropped silently.
- The function upserts the GHL contact, writes a note with every field including attribution, creates an opportunity in the configured pipeline stage, and redirects to `/thank-you/?form=<name>&svc=<service>`.
- Stage routing: `quote*` -> GHL_STAGE_QUOTE, `lm-*` and `guide` -> GHL_STAGE_GUIDE, everything else -> GHL_STAGE_ENQUIRY.
- GTM dataLayer: `lead_submit` on every submission (form_name, service, audience, page); `lead_complete` on /thank-you/ (form_name, service, lead_type). Fire GA4, UET and Google Ads conversions from `lead_complete`.
