# Exp|Arc — Audience Pain-Point Knowledge (research, Aug 2026)

## Universal (homeowners & small business)
- Fear of refusal & red tape: 27% of homeowners call planning a major obstacle (HomeOwners Alliance); ~30,000 householder refusals/yr even at ~88% approval. "Dread" is the word used.
- Confusion triangle: Permitted Development vs Prior Approval vs Full Planning — people wrongly assume PD does/doesn't apply (named the single most common early mistake).
- Planning ≠ Building Regs: widely misunderstood; "we didn't need planning" ≠ regs compliance; sign-off confusion both ways.
- Cost anxiety & opacity: traditional architect planning drawings from ~£5,000 (London firms); market norm £1,200–£2,500 planning-only, £2,500–£5,000 full set; % fees (7–15%) "move" and scare people; hidden extras (council fee £258 householder England, structural engineer £700–£2,000) cause budget surprise. Fixed written price is the killer message.
- Timeline underestimation: design 4+ weeks, council ~8 weeks; people expect faster.
- Neighbours/party wall worry; enforcement horror stories circulate (demolition orders).

## Extensions
- PD limits confusion (3/4/6/8m, heights, half-curtilage, previous extensions eating allowance).
- Larger-home prior-approval route unknown to most.
- Refusal fear → want route confirmed before spending.

## Loft/garage/basement
- Head-height anxiety: "is my loft too low?" (2.2m benchmark) stops thousands; measured wrong.
- Stairs = hidden £5–10k problem (2.0m/1.9m/1.8m headroom, 42° pitch) — regs surprise.
- Trussed roofs, water tanks, insulation build-up eat height. Value upside +20–25% motivates.

## Outdoor structures
- "Do garden rooms need permission?" — height/boundary (2.5m within 2m) & sleeping-use myths.

## Renovations
- Don't realise regs apply without planning; drainage/services surprises; on-site decisions blow budgets.

## Planning service
- Want someone to "deal with the council"; refunds/appeals unknown; pre-app value unclear.

## Business / change of use
- Class E flexibility vs Sui Generis confusion (shop→café often fine; takeaway/pub not).
- Miss the side consents: extractor flues, advertisement consent for signage, pavement licence for tables & chairs.
- Enforcement risk if they open first; landlords eye Class MA office→resi.

## Surveys
- Extras anxiety → self-survey (where permitted & conditions met) saving up to £450 is a strong differentiator + lead magnet.

## Messaging implications
1. Lead with certainty: route confirmed day one, fixed written price, 100% refund if refused.
2. Answer the fear questions on-page (FAQ/AEO) per service.
3. Cost transparency converts: name the extras (council fee, engineer) up front.
4. Self-survey saving (£450) = unique hook for top-of-funnel.
